#ifndef __PARSETEXTMATRIX_H
#define __PARSETEXTMATRIX_H

unsigned parsetextmatrix(char *data,int *sx,int *sy,double **outdata,bool **outnan);

#endif
